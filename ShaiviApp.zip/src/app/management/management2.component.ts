import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-management',
  templateUrl: './management2.component.html',
  styleUrls: ['./management.component.css']
})
export class ManagementComponent2 implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
